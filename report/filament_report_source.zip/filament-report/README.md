# Filament technical report

`main.tex` uses the competition's original ACM `sigconf` template. The fixed subtitle, opening introduction, and acknowledgment text are retained. No institutional affiliation is asserted. The verified author is Jean-Louis Roy, `jeanlouisroyroy@gmail.com`.

## Build

1. Install Tectonic 0.17.0 or a TeX distribution containing `acmart`.
2. Install figure dependencies with `python -m pip install reportlab pillow numpy pycocotools`.
3. From this directory, run `python make_figures.py` and `tectonic -X compile main.tex --keep-logs`.

The figure generator reads a model-generated V23 CSV in `../repository/outputs/submission.csv` (or the explicit path supplied with `--predictions`) and the competition's official test JPEGs in `../../data/`. Generate predictions with the companion repository before rebuilding figures. It does not load test annotations. The supplied diagrams are original; the supplied image overlays were generated from the exact archived V23 predictions. Their provenance is in `figures/provenance.json`. The archived reference CSV is not redistributed in the minimal model release; its hash and identity are provided for independent comparison.

The source template is archived unchanged in `official-template.zip` and extracted under `official-template/`. Source: <https://www.overleaf.com/read/vjztpvrnbrdh#43fbbe>, anonymous read-only access, retrieved 2026-11-06. Overleaf project name: `kaggle_comp_report_fi_segm_2026`; project ID: `6a735222766a5d9bbc55c686`. No remote template content was edited.

## Evidence and scope

- Main result: historical own V23 hybrid012, V3 folds 0--2 and V2 folds 3--4; recovered strict OOF PQ 0.43520179088181965; verified public score 0.39; Kaggle submission 55607242.
- CSV SHA-256: `58b3a7c52c239d309189537636e5b0f76b1a8c2dc67d72bb6eb0338eb18677a1`.
- The source's hybrid-sweep record gives a V2 reference PQ of 0.4311884919628038. Earlier submission descriptions give 0.43383. The report explicitly preserves this distinction rather than presenting these as a replayed, identically calibrated comparison.
- The public 0.55 HDJojo control and its derivative are attributed external artifacts, not the packaged V23 method. No claim is made that V23 reproduces 0.55.
- Model training and full OOF evaluation were not repeated to author the report. Numerical results are labeled historical. Integrity verification does not imply a fresh inference match.
- Public release repository: <https://github.com/Jeanjean59800/solar-filament-segmentation-2026>. It has been created and verified; publication of the accompanying package and the organizers' submission form are handled separately. The manuscript identifies the repository without asserting that a fresh GPU reproduction has completed.

Primary references were checked against the official MAGFiLO documentation, CVF open-access pages, and official Ultralytics documentation. The report uses the template's supplied competition and MAGFiLO bibliography entries and adds citations for PQ, ResNet, clDice, YOLO11, and the ektarr baseline.
